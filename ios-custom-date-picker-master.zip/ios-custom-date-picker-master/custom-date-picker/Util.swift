
import Foundation

class Util{
    func formatDate(date: Date) -> String{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "hh aa"
        return dateFormatter.string(from: date)
    }
}
